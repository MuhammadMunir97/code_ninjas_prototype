package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="parents_ninjas")
public class ParentsNinjas {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="parent_id")
	private int parentId;
	
	@Column(name="ninjas_ninja_id")
	private int ninjaId;
	
	@Column(name="relationship")
	private String relationShip;
	
	
	public ParentsNinjas() {
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	public int getNinjaId() {
		return ninjaId;
	}
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	public String getRelationShip() {
		return relationShip;
	}
	public void setRelationShip(String relationShip) {
		this.relationShip = relationShip;
	}
}
