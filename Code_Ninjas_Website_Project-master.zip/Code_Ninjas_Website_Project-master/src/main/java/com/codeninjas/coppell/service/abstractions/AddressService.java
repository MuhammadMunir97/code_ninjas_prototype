package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Address;

public interface AddressService {
	
	public List<Address> findAll();
	
	public Address findById(int theId);
	
	public void save(Address theAddress);
	
	public void deleteById(int theId);
}
