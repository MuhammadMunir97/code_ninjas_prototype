package com.codeninjas.coppell.entity;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="completed_games")
public class CompletedGames {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	// foreign key many to one relationship
	@Column(name="ninja_id")
	private int ninjaId;
	// foreign key one to one relationship
	@Column(name="game_id")
	private int gameId;
	@Column(name="stars_achieved")
	private int starsAchieved;
	// one to many relationship
	//private Set<Comments> commentsOnGame;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNinjaId() {
		return ninjaId;
	}
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	public int getStarsAchieved() {
		return starsAchieved;
	}
	public void setStarsAchieved(int starsAchieved) {
		this.starsAchieved = starsAchieved;
	}
//	public Set<Comments> getCommentsOnGame() {
//		return commentsOnGame;
//	}
//	public void setCommentsOnGame(Set<Comments> commentsOnGame) {
//		this.commentsOnGame = commentsOnGame;
//	}
}
