package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.Sensei;


public interface SenseiRepository extends JpaRepository<Sensei, Integer> {

}

