package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.SenseiRepository;
import com.codeninjas.coppell.entity.Sensei;
import com.codeninjas.coppell.service.abstractions.SenseiService;


@Service
public class SenseiServiceImplementation implements SenseiService{

	SenseiRepository senseiRepository;
	
	
	@Autowired
	public SenseiServiceImplementation(SenseiRepository senseiRepository) {
		this.senseiRepository = senseiRepository;
	}

	@Override
	public List<Sensei> findAll() {
		return senseiRepository.findAll();
	}

	@Override
	public Sensei findById(int theId) {
		Optional<Sensei> result = senseiRepository.findById(theId);
		
		Sensei theSensei = null;
		if(result.isPresent()) {
			theSensei = result.get();
			return theSensei;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(Sensei theSensei) {
		senseiRepository.save(theSensei);
	}

	@Override
	public void deleteById(int theId) {
		senseiRepository.deleteById(theId);
	}

}
