package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="comments")
public class Comments {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="comment")
	private String comment;
	
	@Column(name="sensei_id")
	private int senseiId;
	
	//foreign key, use @join for best practice
	@Column(name="ninja_id")
	private int ninjaId;
	
	// foreign key, use @join for best practice
	@Column(name="completed_game_id")
	private int completedGame;

	public void setId(int id) {
		this.id = id;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	
	public void setSenseiId(int senseiId) {
		this.senseiId = senseiId;
	}

	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}

	public void setCompletedGame(int completedGame) {
		this.completedGame = completedGame;
	}

	public int getId() {
		return id;
	}

	public String getComment() {
		return comment;
	}

	public int getSenseiId() {
		return senseiId;
	}

	public int getNinjaId() {
		return ninjaId;
	}

	public int getCompletedGame() {
		return completedGame;
	}
}
