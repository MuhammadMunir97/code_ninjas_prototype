package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.ParentsRepository;
import com.codeninjas.coppell.entity.Parents;
import com.codeninjas.coppell.service.abstractions.ParentsService;


@Service
public class ParentsServiceImplementation implements ParentsService{

	ParentsRepository parentsRepository;
	
	
	@Autowired
	public ParentsServiceImplementation(ParentsRepository parentsRepository) {
		this.parentsRepository = parentsRepository;
	}

	@Override
	public List<Parents> findAll() {
		return parentsRepository.findAll();
	}

	@Override
	public Parents findById(int theId) {
		Optional<Parents> result = parentsRepository.findById(theId);
		
		Parents theParents = null;
		if(result.isPresent()) {
			theParents = result.get();
			return theParents;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(Parents theParents) {
		parentsRepository.save(theParents);
	}

	@Override
	public void deleteById(int theId) {
		parentsRepository.deleteById(theId);
	}

}
