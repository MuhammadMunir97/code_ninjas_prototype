package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Ninja;

public interface NinjaService {
	
	public List<Ninja> findAll();
	
	public Ninja findById(int theId);
	
	public void save(Ninja theNinja);
	
	public void deleteById(int theId);
}
