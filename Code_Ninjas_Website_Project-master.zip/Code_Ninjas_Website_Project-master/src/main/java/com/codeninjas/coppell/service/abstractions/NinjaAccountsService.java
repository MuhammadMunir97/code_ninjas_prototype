package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.NinjaAccounts;

public interface NinjaAccountsService {
	
	public List<NinjaAccounts> findAll();
	
	public NinjaAccounts findById(int theId);
	
	public void save(NinjaAccounts theNinjaAccounts);
	
	public void deleteById(int theId);
}
