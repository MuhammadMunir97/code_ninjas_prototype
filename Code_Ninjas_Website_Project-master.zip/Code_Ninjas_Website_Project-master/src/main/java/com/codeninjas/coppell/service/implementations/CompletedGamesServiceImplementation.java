package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.CompletedGamesRepository;
import com.codeninjas.coppell.entity.CompletedGames;
import com.codeninjas.coppell.service.abstractions.CompletedGamesService;


@Service
public class CompletedGamesServiceImplementation implements CompletedGamesService{

	CompletedGamesRepository completedGamesRepository;
	
	
	@Autowired
	public CompletedGamesServiceImplementation(CompletedGamesRepository completedGamesRepository) {
		this.completedGamesRepository = completedGamesRepository;
	}

	@Override
	public List<CompletedGames> findAll() {
		return completedGamesRepository.findAll();
	}

	@Override
	public CompletedGames findById(int theId) {
		Optional<CompletedGames> result = completedGamesRepository.findById(theId);
		
		CompletedGames theCompletedGames = null;
		if(result.isPresent()) {
			theCompletedGames = result.get();
			return theCompletedGames;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(CompletedGames theCompletedGames) {
		completedGamesRepository.save(theCompletedGames);
	}

	@Override
	public void deleteById(int theId) {
		completedGamesRepository.deleteById(theId);
	}

}
