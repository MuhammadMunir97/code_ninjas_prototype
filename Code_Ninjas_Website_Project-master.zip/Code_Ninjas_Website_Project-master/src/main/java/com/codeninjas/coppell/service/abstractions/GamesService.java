package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Games;

public interface GamesService {
	
	public List<Games> findAll();
	
	public Games findById(int theId);
	
	public void save(Games theGames);
	
	public void deleteById(int theId);
}
