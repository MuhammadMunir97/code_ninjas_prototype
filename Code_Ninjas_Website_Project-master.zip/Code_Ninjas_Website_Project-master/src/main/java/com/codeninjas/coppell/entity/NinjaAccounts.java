package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="ninja_accounts")
public class NinjaAccounts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="ninjas_ninja_id")
	private int ninjaId;
	
	@Column(name="ninja_username")
	private String ninjaUsername;
	
	@Column(name="ninja_password")
	private String ninjaPassword;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNinjaId() {
		return ninjaId;
	}
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	public String getNinjaUsername() {
		return ninjaUsername;
	}
	public void setNinjaUsername(String ninjaUsername) {
		this.ninjaUsername = ninjaUsername;
	}
	public String getNinjaPassword() {
		return ninjaPassword;
	}
	public void setNinjaPassword(String ninjaPassword) {
		this.ninjaPassword = ninjaPassword;
	}
	
	
}
