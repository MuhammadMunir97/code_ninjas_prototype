package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.Session;


public interface SessionRepository extends JpaRepository<Session, Integer> {

}

