package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.CommentsRepository;
import com.codeninjas.coppell.entity.Comments;
import com.codeninjas.coppell.service.abstractions.CommentsService;


@Service
public class CommentsServiceImplementation implements CommentsService{

	CommentsRepository commentsRepository;
	
	
	@Autowired
	public CommentsServiceImplementation(CommentsRepository commentsRepository) {
		this.commentsRepository = commentsRepository;
	}

	@Override
	public List<Comments> findAll() {
		return commentsRepository.findAll();
	}

	@Override
	public Comments findById(int theId) {
		Optional<Comments> result = commentsRepository.findById(theId);
		
		Comments theComments = null;
		if(result.isPresent()) {
			theComments = result.get();
			return theComments;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(Comments theComments) {
		commentsRepository.save(theComments);
	}

	@Override
	public void deleteById(int theId) {
		commentsRepository.deleteById(theId);
	}

}
