package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.BeltsRepository;
import com.codeninjas.coppell.entity.Belts;
import com.codeninjas.coppell.service.abstractions.BeltsService;


@Service
public class BeltsServiceImplementation implements BeltsService{

	BeltsRepository beltsRepository;
	
	
	@Autowired
	public BeltsServiceImplementation(BeltsRepository beltsRepository) {
		this.beltsRepository = beltsRepository;
	}

	@Override
	public List<Belts> findAll() {
		return beltsRepository.findAll();
	}

	@Override
	public Belts findById(int theId) {
		Optional<Belts> result = beltsRepository.findById(theId);
		
		Belts theBelts = null;
		if(result.isPresent()) {
			theBelts = result.get();
			return theBelts;
		}else {
			throw new RuntimeException("Did not find Belt id - " + theId);
		}
	}

	@Override
	public void save(Belts theBelts) {
		beltsRepository.save(theBelts);
	}

	@Override
	public void deleteById(int theId) {
		beltsRepository.deleteById(theId);
	}

}
