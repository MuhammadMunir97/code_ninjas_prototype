package com.codeninjas.coppell.entity;

import java.time.ZonedDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@ Table(name="parents")
public class Parents {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String LastName;
	
	@Column(name="phone_num")
	private String phoneNum;
	
	@Column(name="email_id")
	private String email;
	
	
	// one to one relationship foreignKey
	private int addressId;
	
	@Column(name="created_at")
	private ZonedDateTime createdAt;
	
	@Column(name="updated_at")
	private ZonedDateTime updatedAt;
	
	// one to many relationship
	//private Set<ParentsNinjas> parentNinjas;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public ZonedDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(ZonedDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public ZonedDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(ZonedDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

//	public Set<ParentsNinjas> getParentNinjas() {
//		return parentNinjas;
//	}
//
//	public void setParentNinjas(Set<ParentsNinjas> parentNinjas) {
//		this.parentNinjas = parentNinjas;
//	}
	
	@PrePersist
	public void onCreate() {
		createdAt = ZonedDateTime.now();
	}
	@PreUpdate
	public void onUpdate() {
		updatedAt = ZonedDateTime.now();
	}
	
}
