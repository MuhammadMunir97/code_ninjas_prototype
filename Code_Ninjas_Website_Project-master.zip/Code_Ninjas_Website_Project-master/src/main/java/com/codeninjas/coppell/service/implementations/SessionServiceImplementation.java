package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.SessionRepository;
import com.codeninjas.coppell.entity.Session;
import com.codeninjas.coppell.service.abstractions.SessionService;


@Service
public class SessionServiceImplementation implements SessionService{

	SessionRepository sessionRepository;
	
	
	@Autowired
	public SessionServiceImplementation(SessionRepository sessionRepository) {
		this.sessionRepository = sessionRepository;
	}

	@Override
	public List<Session> findAll() {
		return sessionRepository.findAll();
	}

	@Override
	public Session findById(int theId) {
		Optional<Session> result = sessionRepository.findById(theId);
		
		Session theSession = null;
		if(result.isPresent()) {
			theSession = result.get();
			return theSession;
		}else {
			throw new RuntimeException("Did not find Session id - " + theId);
		}
	}

	@Override
	public void save(Session theSession) {
		sessionRepository.save(theSession);
	}

	@Override
	public void deleteById(int theId) {
		sessionRepository.deleteById(theId);
	}

}
