package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Comments;

public interface CommentsService {
	
	public List<Comments> findAll();
	
	public Comments findById(int theId);
	
	public void save(Comments theComments);
	
	public void deleteById(int theId);
}
