package com.codeninjas.coppell.entity;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="session")
public class Session {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="session_started")
	private LocalDateTime sessionStarted;
	
	@Column(name="session_finished")
	private LocalDateTime sessionEnded;
	
	@Column(name="session_notes")
	private String sessionNotes;
	// foreign key 
	private int ninjaId;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDateTime getSessionStarted() {
		return sessionStarted;
	}
	public void setSessionStarted(LocalDateTime sessionStarted) {
		this.sessionStarted = sessionStarted;
	}
	public LocalDateTime getSessionEnded() {
		return sessionEnded;
	}
	public void setSessionEnded(LocalDateTime sessionEnded) {
		this.sessionEnded = sessionEnded;
	}
	public String getSessionNotes() {
		return sessionNotes;
	}
	public void setSessionNotes(String sessionNotes) {
		this.sessionNotes = sessionNotes;
	}
	public int getNinjaId() {
		return ninjaId;
	}
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	
}
