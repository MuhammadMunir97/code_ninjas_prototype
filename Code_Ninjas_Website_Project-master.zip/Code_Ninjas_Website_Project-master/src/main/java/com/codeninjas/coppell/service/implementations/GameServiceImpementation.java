package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.GamesRepository;
import com.codeninjas.coppell.entity.Games;
import com.codeninjas.coppell.service.abstractions.GamesService;


@Service
public class GameServiceImpementation implements GamesService{

	GamesRepository gamesRepository;
	
	
	@Autowired
	public GameServiceImpementation(GamesRepository gamesRepository) {
		this.gamesRepository = gamesRepository;
	}

	@Override
	public List<Games> findAll() {
		return gamesRepository.findAll();
	}

	@Override
	public Games findById(int theId) {
		Optional<Games> result = gamesRepository.findById(theId);
		
		Games theGames = null;
		if(result.isPresent()) {
			theGames = result.get();
			return theGames;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(Games theGames) {
		gamesRepository.save(theGames);
	}

	@Override
	public void deleteById(int theId) {
		gamesRepository.deleteById(theId);
	}

}
