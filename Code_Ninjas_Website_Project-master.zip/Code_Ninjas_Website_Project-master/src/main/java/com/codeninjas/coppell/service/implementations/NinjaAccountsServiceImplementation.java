package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.NinjaAccountsRepository;
import com.codeninjas.coppell.entity.NinjaAccounts;
import com.codeninjas.coppell.service.abstractions.NinjaAccountsService;


@Service
public class NinjaAccountsServiceImplementation implements NinjaAccountsService{

	NinjaAccountsRepository ninjaAccountsRepository;
	
	
	@Autowired
	public NinjaAccountsServiceImplementation(NinjaAccountsRepository ninjaAccountsRepository) {
		this.ninjaAccountsRepository = ninjaAccountsRepository;
	}

	@Override
	public List<NinjaAccounts> findAll() {
		return ninjaAccountsRepository.findAll();
	}

	@Override
	public NinjaAccounts findById(int theId) {
		Optional<NinjaAccounts> result = ninjaAccountsRepository.findById(theId);
		
		NinjaAccounts theNinjaAccounts = null;
		if(result.isPresent()) {
			theNinjaAccounts = result.get();
			return theNinjaAccounts;
		}else {
			throw new RuntimeException("Did not find Ninja Account id - " + theId);
		}
	}

	@Override
	public void save(NinjaAccounts theNinjaAccounts) {
		ninjaAccountsRepository.save(theNinjaAccounts);
	}

	@Override
	public void deleteById(int theId) {
		ninjaAccountsRepository.deleteById(theId);
	}

}
