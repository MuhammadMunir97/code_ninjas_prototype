package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Belts;

public interface BeltsService {
	
	public List<Belts> findAll();
	
	public Belts findById(int theId);
	
	public void save(Belts theBelts);
	
	public void deleteById(int theId);
}
