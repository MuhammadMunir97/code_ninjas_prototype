//package com.codeninjas.coppell.restcontroller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//
//import com.codeninjas.coppell.entity.ninjas;
//import com.codeninjas.coppell.service.NinjaService;
//
//@RestController
//@RequestMapping("/api")
//public class NinjaRestController {
//
//	private NinjaService ninjaService;
//	// test this quick and fast (using constructor injection)
//	@Autowired
//	public NinjaRestController(NinjaService ninjaService) {
//		this.ninjaService = ninjaService;
//	}
//	
//	@GetMapping("/ninjas")
//	public List<ninjas> findAll () {
//		return ninjaService.findAll();
//	}
//	
//		// add mapping for GET /employees/{employeeId}
//		
//		@GetMapping("/ninjas/{ninjaId}")
//		public ninjas getEmployee(@PathVariable int ninjaId) {
//			
//			ninjas theNinja = ninjaService.findById(ninjaId);
//			
//			if (theNinja == null) {
//				throw new RuntimeException("Ninja id not found - " + theNinja);
//			}
//			
//			return theNinja;
//		}
//		
//		// add mapping for POST /employees - add new employee
//		
//		@PostMapping("/ninjas")
//		public ninjas addNinja(@RequestBody ninjas theNinja) {
//			
//			// also just in case they pass an id in JSON ... set id to 0
//			// this is to force a save of new item ... instead of update
//			
//			theNinja.setNinjaId(0);
//			
//			ninjaService.save(theNinja);
//			
//			return theNinja;
//		}
//		
//		// add mapping for PUT /employees - update existing employee
//		
//		@PutMapping("/ninjas")
//		public ninjas updateNinjas(@RequestBody ninjas theNinja) {
//			
//			ninjaService.save(theNinja);
//			
//			return theNinja;
//		}
//		
//		// add mapping for DELETE /employees/{employeeId} - delete employee
//		
//		@DeleteMapping("/ninjas/{ninjaId}")
//		public String deleteEmployee(@PathVariable int ninjaId) {
//			
//			ninjas tempNinja = ninjaService.findById(ninjaId);
//			
//			// throw exception if null
//			
//			if (tempNinja == null) {
//				throw new RuntimeException("Ninja id not found - " + ninjaId);
//			}
//			
//			ninjaService.deleteById(ninjaId);
//			
//			return "Deleted ninja id - " + ninjaId;
//		}
//		
//	
//}
