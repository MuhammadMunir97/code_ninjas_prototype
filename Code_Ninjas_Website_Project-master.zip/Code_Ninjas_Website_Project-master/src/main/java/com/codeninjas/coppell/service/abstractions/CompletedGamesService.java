package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.CompletedGames;

public interface CompletedGamesService {
	
	public List<CompletedGames> findAll();
	
	public CompletedGames findById(int theId);
	
	public void save(CompletedGames theCompletedGames);
	
	public void deleteById(int theId);
}
