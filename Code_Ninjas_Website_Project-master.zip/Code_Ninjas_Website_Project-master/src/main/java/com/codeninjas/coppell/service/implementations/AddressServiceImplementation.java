package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.AddressRepository;
import com.codeninjas.coppell.entity.Address;
import com.codeninjas.coppell.service.abstractions.AddressService;


@Service
public class AddressServiceImplementation implements AddressService{

	AddressRepository addressRepository;
	
	
	@Autowired
	public AddressServiceImplementation(AddressRepository addressRepository) {
		this.addressRepository = addressRepository;
	}

	@Override
	public List<Address> findAll() {
		return addressRepository.findAll();
	}

	@Override
	public Address findById(int theId) {
		Optional<Address> result = addressRepository.findById(theId);
		
		Address theAddress = null;
		if(result.isPresent()) {
			theAddress = result.get();
			return theAddress;
		}else {
			throw new RuntimeException("Did not find Game id - " + theId);
		}
	}

	@Override
	public void save(Address theAddress) {
		addressRepository.save(theAddress);
	}

	@Override
	public void deleteById(int theId) {
		addressRepository.deleteById(theId);
	}

}
