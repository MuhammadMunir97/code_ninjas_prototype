package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Parents;

public interface ParentsService {
	
	public List<Parents> findAll();
	
	public Parents findById(int theId);
	
	public void save(Parents theParents);
	
	public void deleteById(int theId);
}
