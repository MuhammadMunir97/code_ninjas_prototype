package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.Comments;


public interface CommentsRepository extends JpaRepository<Comments, Integer> {

}

