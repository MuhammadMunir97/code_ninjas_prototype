package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.ParentsNinjasRepository;
import com.codeninjas.coppell.entity.ParentsNinjas;
import com.codeninjas.coppell.service.abstractions.ParentsNinjasService;


@Service
public class ParentsNinjasServiceImplementation implements ParentsNinjasService{

	ParentsNinjasRepository parentsNinjasRepository;
	
	
	@Autowired
	public ParentsNinjasServiceImplementation(ParentsNinjasRepository parentsNinjasRepository) {
		this.parentsNinjasRepository = parentsNinjasRepository;
	}

	@Override
	public List<ParentsNinjas> findAll() {
		return parentsNinjasRepository.findAll();
	}

	@Override
	public ParentsNinjas findById(int theId) {
		Optional<ParentsNinjas> result = parentsNinjasRepository.findById(theId);
		
		ParentsNinjas theParentsNinjas = null;
		if(result.isPresent()) {
			theParentsNinjas = result.get();
			return theParentsNinjas;
		}else {
			throw new RuntimeException("Did not find ParentNinja id - " + theId);
		}
	}

	@Override
	public void save(ParentsNinjas theParentsNinjas) {
		parentsNinjasRepository.save(theParentsNinjas);
	}

	@Override
	public void deleteById(int theId) {
		parentsNinjasRepository.deleteById(theId);
	}

}
