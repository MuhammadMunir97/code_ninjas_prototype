package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.AccountType;

public interface AccountTypeService {
	
	public List<AccountType> findAll();
	
	public AccountType findById(int theId);
	
	public void save(AccountType theAccountType);
	
	public void deleteById(int theId);
}
