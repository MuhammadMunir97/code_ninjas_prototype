package com.codeninjas.coppell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeNinjasWebsiteMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeNinjasWebsiteMainApplication.class, args);
	}

}

// TODO entity relationships with eachother
// TODO setting up the service implementation layer
// TODO setting up the view layer to make sure the pipelines are working 

// TODO clean your code, identify the places where you can use abstraction
// TODO Introduce business logic

// identify the correct page structure 
// use the structure to make a web page