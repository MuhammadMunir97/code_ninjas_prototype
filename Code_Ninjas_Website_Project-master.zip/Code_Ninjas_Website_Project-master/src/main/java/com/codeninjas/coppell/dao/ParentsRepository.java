package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.Parents;


public interface ParentsRepository extends JpaRepository<Parents, Integer> {

}

