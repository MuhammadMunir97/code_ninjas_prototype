package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.NinjaBeltsRepository;
import com.codeninjas.coppell.entity.NinjaBelts;
import com.codeninjas.coppell.service.abstractions.NinjaBeltsService;


@Service
public class NinjaBeltsServiceImplementation implements NinjaBeltsService{

	NinjaBeltsRepository ninjaBeltsRepository;
	
	
	@Autowired
	public NinjaBeltsServiceImplementation(NinjaBeltsRepository ninjaBeltsRepository) {
		this.ninjaBeltsRepository = ninjaBeltsRepository;
	}

	@Override
	public List<NinjaBelts> findAll() {
		return ninjaBeltsRepository.findAll();
	}

	@Override
	public NinjaBelts findById(int theId) {
		Optional<NinjaBelts> result = ninjaBeltsRepository.findById(theId);
		
		NinjaBelts theNinjaBelts = null;
		if(result.isPresent()) {
			theNinjaBelts = result.get();
			return theNinjaBelts;
		}else {
			throw new RuntimeException("Did not find Ninja Belt id - " + theId);
		}
	}

	@Override
	public void save(NinjaBelts theNinjaBelts) {
		ninjaBeltsRepository.save(theNinjaBelts);
	}

	@Override
	public void deleteById(int theId) {
		ninjaBeltsRepository.deleteById(theId);
	}

}
