package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.NinjaRepository;
import com.codeninjas.coppell.entity.Ninja;
import com.codeninjas.coppell.service.abstractions.NinjaService;

@Service
public class NinjaServiceImplementation implements NinjaService {
	
	private NinjaRepository theNinjaRepository;
	
	@Autowired
	public NinjaServiceImplementation(NinjaRepository theNinjaRepository) {
		this.theNinjaRepository = theNinjaRepository;
	}

	@Override
	public List<Ninja> findAll() {
		return theNinjaRepository.findAllByOrderByLastNameAsc();
	}

	@Override
	public Ninja findById(int theId) {
		Optional<Ninja> result = theNinjaRepository.findById(theId);
		
		Ninja theNinjas = null;
		if(result.isPresent()) {
			theNinjas = result.get();
			return theNinjas;
		}else {
			throw new RuntimeException("Did not find ninja id - " + theId);
		}
	}

	@Override
	public void save(Ninja theNinja) {
		theNinjaRepository.save(theNinja);
	}

	@Override
	public void deleteById(int theId) {
		theNinjaRepository.deleteById(theId);
	}

}
