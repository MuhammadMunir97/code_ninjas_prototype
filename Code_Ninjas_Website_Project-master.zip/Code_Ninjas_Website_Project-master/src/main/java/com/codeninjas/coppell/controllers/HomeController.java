package com.codeninjas.coppell.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codeninjas.coppell.entity.Ninja;
import com.codeninjas.coppell.service.abstractions.NinjaService;

@Controller
@RequestMapping("/home")
public class HomeController {

	
	private NinjaService ninjaService;
	// test this quick and fast (using constructor injection)

	public HomeController(NinjaService ninjaService) {
		this.ninjaService = ninjaService;
	}
	
	@GetMapping("/ninjas")
	public String findAll (Model theModel) {
		
		List<Ninja> allTheNinjas = ninjaService.findAll();
		
		theModel.addAttribute("allNinjas" , allTheNinjas);		
		return "ninjas/list-ninjas";
	}
	
	
	
	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("ninjaId") int theId, 
			Model theModel) {
		// get the ninja from the service
		Ninja theNinja = ninjaService.findById(theId);
		// set employee as a model attribute
		theModel.addAttribute("Ninja" , theNinja);
		// send over to form
		
		return "ninjas/NinjaForm";
		
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam("ninjaId") int theId) {
		// delete the ninja
		ninjaService.deleteById(theId);
		
		// redirect to ninja list
		return "redirect:/home/ninjas";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(@ModelAttribute ("Ninja") Ninja theNinja) {
		return "ninjas/NinjaForm";
		
	}
	
	@PostMapping("/save")
	public String saveNinja(@Valid @ModelAttribute ("Ninja") Ninja theNinja ,  BindingResult result) {
		// save the ninja
		if (result.hasErrors()) {
        return "ninjas/list-ninjas";
    } else {
    	ninjaService.save(theNinja);
    	// use a redirect to prevent duplicate submissions
    	return "redirect:/home/ninjas";
    }
	}
	// TODO add a flash error so the user knows that his ninja was not approved and saved inside the database
}
