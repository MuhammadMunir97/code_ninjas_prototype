package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="games")
public class Games {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="game_name")
	private String gameName;
	
	@Column(name="game_concepts")
	private String gameConcept;
	// foreign key many to one relationship
	
	@Column(name="belt_id")
	private int beltId;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public String getGameConcept() {
		return gameConcept;
	}
	public void setGameConcept(String gameConcept) {
		this.gameConcept = gameConcept;
	}
	public int getBeltId() {
		return beltId;
	}
	public void setBeltId(int beltId) {
		this.beltId = beltId;
	}
}
