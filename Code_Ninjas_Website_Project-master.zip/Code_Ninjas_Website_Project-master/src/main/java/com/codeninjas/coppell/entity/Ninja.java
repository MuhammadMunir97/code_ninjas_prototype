package com.codeninjas.coppell.entity;

import java.time.ZonedDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
//import javax.persistence.OneToMany;
import javax.persistence.Table;






@Entity
@ Table(name="ninjas")
public class Ninja {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int ninjaId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="stars_achieved")
	private int starsAchieved;
	
	@Column(name="time_spent_coding")
	private double timeSpentCOding;
	
	@Column(name="current_belt_id")
	private int currentBeltId;
	
	
	public Ninja() {
		
		
	}
	// TODO put all the error checking in the ninja to ensure correct information is getting processed
	
	// this will not let this update the first time
	@Column(updatable=false)
	private ZonedDateTime createdAt;
	private ZonedDateTime updatedAt;
	
	
	// exxample @OneToOne(mappedBy="person", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    //private License license; person above would be the foreign key, specifically java property, and inside the other object you 
	// will have to specify that you are mapping an object to it the adjacent object should look something like this
	//	@ManyToOne(fetch = FetchType.LAZY)
	//   @JoinColumn(name="dojo_id") dojo_id here would be the foreign key inside the table with many to one rel, table property here,
	// private Dojo dojo;
	// refer to one to many coding dojo 
	
	
	// describe all the one to many relationships
	
	// in your objects relationship from the other side 
	// add this line it is a best practice and will help you 
	// in having less tables created while hibernate runs this
	
	public ZonedDateTime getCreatedAt() {
		return createdAt;
	}
	public ZonedDateTime getUpdatedAt() {
		return updatedAt;
	}
	
	// TODO set all the relational mappings inside ninja
	// this one is for the parent_ninja relationship as it is many to many
	//@OneToMany(mappedBy="parents_ninjas")
//	private Set<ParentsNinjas> parentNinjas;	
//	// all the sessions attended by this ninja
//	//@OneToMany(mappedBy="session")
//	private Set<Session> sessionsAttended;
//	// all the sessions attended by this ninja
//	//@OneToMany(mappedBy="comments")
//	private Set<Comments> comments;
//	// all the sessions attended by this ninja
//	//@OneToMany(mappedBy="completed_games")
//	private Set<CompletedGames> completedGames;
//	
//	
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setStarsAchieved(int starsAchieved) {
		this.starsAchieved = starsAchieved;
	}
	public void setTimeSpentCOding(double timeSpentCOding) {
		this.timeSpentCOding = timeSpentCOding;
	}
	public void setCreatedAt(ZonedDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public void setUpdatedAt(ZonedDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
//	public void setParentNinjas(Set<ParentsNinjas> parentNinjas) {
//		this.parentNinjas = parentNinjas;
//	}
//	public void setSessionsAttended(Set<Session> sessionsAttended) {
//		this.sessionsAttended = sessionsAttended;
//	}
//	public void setComments(Set<Comments> comments) {
//		this.comments = comments;
//	}
//	public void setCompletedGames(Set<CompletedGames> completedGames) {
//		this.completedGames = completedGames;
//	}
	public int getNinjaId() {
		return ninjaId;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public int getStarsAchieved() {
		return starsAchieved;
	}
	public double getTimeSpentCOding() {
		return timeSpentCOding;
	}
//	public Set<ParentsNinjas> getParentNinjas() {
//		return parentNinjas;
//	}
//	public Set<Session> getSessionsAttended() {
//		return sessionsAttended;
//	}
//	public Set<Comments> getComments() {
//		return comments;
//	}
//	public Set<CompletedGames> getCompletedGames() {
//		return completedGames;
//	}
	
	public int getCurrentBeltId() {
		return currentBeltId;
	}
	public void setCurrentBeltId(int currentBeltId) {
		this.currentBeltId = currentBeltId;
	}
	
	
	@PrePersist
	public void onCreate() {
		// so to avoid errors and test an initial id of 1 is being passed
		currentBeltId = 1;
		createdAt = ZonedDateTime.now();
	}
	@PreUpdate
	public void onUpdate() {
		updatedAt = ZonedDateTime.now();
	}
}
