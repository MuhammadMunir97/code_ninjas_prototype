package com.codeninjas.coppell.entity;

import java.time.ZonedDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@ Table(name="belts")
public class Belts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="belt_name")
	private String beltName;
	
	@Column(name="belt_description")
	private String beltDescription;
	
	@Column(name="created_at")
	private ZonedDateTime createdAt;
	
	@Column(name="updated_at")
	private ZonedDateTime updatedAt;
	
	// one to many relationship
	//private Set<Games> allGamesInBelt;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBeltName() {
		return beltName;
	}

	public void setBeltName(String beltName) {
		this.beltName = beltName;
	}

	public String getBeltDescription() {
		return beltDescription;
	}

	public void setBeltDescription(String beltDescription) {
		this.beltDescription = beltDescription;
	}

	public ZonedDateTime getCreatedAt() {
		return createdAt;
	}

	public ZonedDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(ZonedDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

//	public Set<Games> getAllGamesInBelt() {
//		return allGamesInBelt;
//	}
//
//	public void setAllGamesInBelt(Set<Games> allGamesInBelt) {
//		this.allGamesInBelt = allGamesInBelt;
//	}
	@PrePersist
	public void onCreate() {
		createdAt = ZonedDateTime.now();
	}
	@PreUpdate
	public void onUpdate() {
		updatedAt = ZonedDateTime.now();
	}
	
	
}
