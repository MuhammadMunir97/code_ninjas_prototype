package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.Games;


public interface GamesRepository extends JpaRepository<Games, Integer> {

}

