package com.codeninjas.coppell.service.implementations;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeninjas.coppell.dao.AccountTypeRepository;
import com.codeninjas.coppell.entity.AccountType;
import com.codeninjas.coppell.service.abstractions.AccountTypeService;


@Service
public class AccountTypeServiceImplementation implements AccountTypeService{

	AccountTypeRepository accountTypeRepository;
	
	
	@Autowired
	public AccountTypeServiceImplementation(AccountTypeRepository  accountTypeRepository) {
		this.accountTypeRepository = accountTypeRepository;
	}

	@Override
	public List<AccountType> findAll() {
		return accountTypeRepository.findAll();
	}

	@Override
	public AccountType findById(int theId) {
		Optional<AccountType> result = accountTypeRepository.findById(theId);
		
		AccountType theAccountType = null;
		if(result.isPresent()) {
			theAccountType = result.get();
			return theAccountType;
		}else {
			throw new RuntimeException("Did not find AccountType id - " + theId);
		}
	}

	@Override
	public void save(AccountType theAccountType) {
		accountTypeRepository.save(theAccountType);
	}

	@Override
	public void deleteById(int theId) {
		accountTypeRepository.deleteById(theId);
	}

}
