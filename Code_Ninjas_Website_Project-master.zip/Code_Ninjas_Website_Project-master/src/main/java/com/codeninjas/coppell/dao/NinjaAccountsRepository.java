package com.codeninjas.coppell.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codeninjas.coppell.entity.NinjaAccounts;


public interface NinjaAccountsRepository extends JpaRepository<NinjaAccounts, Integer> {

}

