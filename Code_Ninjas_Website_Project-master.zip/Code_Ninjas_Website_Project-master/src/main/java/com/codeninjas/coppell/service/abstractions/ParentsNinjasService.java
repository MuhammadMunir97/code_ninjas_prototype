package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.ParentsNinjas;

public interface ParentsNinjasService {
	
	public List<ParentsNinjas> findAll();
	
	public ParentsNinjas findById(int theId);
	
	public void save(ParentsNinjas theParentsNinjas);
	
	public void deleteById(int theId);
}
