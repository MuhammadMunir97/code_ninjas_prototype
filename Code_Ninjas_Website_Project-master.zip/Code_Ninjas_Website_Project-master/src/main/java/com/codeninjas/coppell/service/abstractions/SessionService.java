package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Session;

public interface SessionService {
	
	public List<Session> findAll();
	
	public Session findById(int theId);
	
	public void save(Session theSession);
	
	public void deleteById(int theId);
}
