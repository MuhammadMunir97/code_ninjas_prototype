package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.Sensei;

public interface SenseiService {
	
	public List<Sensei> findAll();
	
	public Sensei findById(int theId);
	
	public void save(Sensei theSensei);
	
	public void deleteById(int theId);
}
