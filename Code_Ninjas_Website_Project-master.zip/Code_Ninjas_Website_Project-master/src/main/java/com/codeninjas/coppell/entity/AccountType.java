package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="account_type")
public class AccountType {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="account_name")
	private String accountName;
	
	@Column(name="account_description")
	private String accountDescription;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String account_name) {
		this.accountName = account_name;
	}
	public String getAccountDescription() {
		return accountDescription;
	}
	public void setAccountDescription(String account_description) {
		this.accountDescription = account_description;
	}
}
