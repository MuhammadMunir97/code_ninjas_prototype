package com.codeninjas.coppell.service.abstractions;

import java.util.List;

import com.codeninjas.coppell.entity.NinjaBelts;

public interface NinjaBeltsService {
	
	public List<NinjaBelts> findAll();
	
	public NinjaBelts findById(int theId);
	
	public void save(NinjaBelts theGames);
	
	public void deleteById(int theId);
}
