package com.codeninjas.coppell.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@ Table(name="ninja_belts")
public class NinjaBelts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="ninja_id")
	private int ninjaId;
	
	@Column(name="belt_id")
	private int beltId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNinjaId() {
		return ninjaId;
	}
	public void setNinjaId(int ninjaId) {
		this.ninjaId = ninjaId;
	}
	public int getBeltId() {
		return beltId;
	}
	public void setBeltId(int beltId) {
		this.beltId = beltId;
	}
	
	
}
