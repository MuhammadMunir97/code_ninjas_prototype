package com.codeninjas.coppell.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codeninjas.coppell.entity.Ninja;

public interface NinjaRepository extends JpaRepository<Ninja, Integer> {

	 // spring data jpa 
	
	//add a method to sort by last name
	public List<Ninja> findAllByOrderByLastNameAsc();
	
}
